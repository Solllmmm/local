function showLoadingAnimation() {
  document.getElementById('loading').style.display = 'block';
}

function hideLoadingAnimation() {
  document.getElementById('loading').style.display = 'none';
}