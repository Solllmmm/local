for i in range(365):
    print( "[data[{}]['day'], data[{}]['month'], data[{}]['aqi']],".format(i,i,i))