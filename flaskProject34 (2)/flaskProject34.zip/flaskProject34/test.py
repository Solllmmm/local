import requests
import json

# headers = {'Content-Type': 'application/json'} # 设置请求头


url = 'http://127.0.0.1:7077/v1/chat/completions'

# 请求体数据
payload = {
    "channelId": "1236224487763083307",
    "messages": [
        {
            "content": "{'category': '优', 'aqi': 21.0, 'pm10': 18.0, 'pm2.5': 14.0, 'no2': 17.0, 'so2': 7.0, 'co': 0.5, 'o3': 108.0}{'category': '优', 'aqi': 28.0, 'pm10': 10.0, 'pm2.5': 5.0, 'no2': 10.0, 'so2': 3.0, 'co': 0.5, 'o3': 89.0}",
            "role": "user"
        }
    ],
    "model": "gpt-4-turbo-128k",
    "stream": False
}

# 发送 POST 请求
response = requests.post(url, data=json.dumps(payload))

# 输出响应内容
print(response.text)
